from django.apps import AppConfig


class PartesConfig(AppConfig):
    name = 'partes'
